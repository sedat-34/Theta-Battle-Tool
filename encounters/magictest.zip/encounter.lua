--Load your custom enemies in here!

require "mizzle"

local Encounter = {}

function Encounter:new()

    self.Box = Battlebox()

    local kris_anims = {

        --These used to be number-indexed. They are now string-indexed for clarity.
        --The animations of these specific keys still need to exist for all party members.
        --(Not the names)

        ["idle"] = {name = "krisIdle", length = 6, FPS = 6, looping = true, xOffset = 0, yOffset = 0},
        ["attack"] = {name = "krisAttack", length = 8, FPS = 15, looping = false, xOffset = 5, yOffset = -20},
        ["act"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0},
	["magic"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0},
        ["item"] = {name = "krisItem", length = 8, FPS = 12, looping = false, xOffset = -21, yOffset = -15},
        ["spare"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0}, --I'm fairly confident that Kris uses the same animation for sparing and acting.
        ["defend"] = {name = "krisDefend", length = 6, FPS = 12, looping = false, xOffset = 0, yOffset = -7},
        ["hurt"] = {name = "krisHurt", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -20},
        ["down"] = {name = "krisDown", length = 1, FPS = 1, looping = true, xOffset = -60, yOffset = -20},
        ["end"] = {name = "krisEnd", length = 9, FPS = 10, looping = false, xOffset = -48, yOffset = -24},
        ["endloop"] = {name = "krisEndLoop", length = 1, FPS = 1, looping = true, xOffset = -48, yOffset = -24},
        ["ATTACKUI"] = {name = "krisAttackWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -20},
        ["ACTUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0},
	["MAGICUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}, --Testing magic with existing Kris sprites.
        ["SPAREUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}, --Again, sparing is visually the same as acting. 
        ["DEFEND"] = {name = "krisDefendLoop", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -7}, --Unlooping animations set animation to default, so this animation is required to keep their last sprite.
    }

    local kris_buttons = { --Generally FIGHT/ACT/ITEM/SPARE/DEFEND but I used ATTACK for some reason
                           --And because it's written all over the code I can't change it anymore
                           --Not to be confused with the keys in kris_anims
        [1] = {"attack"},
        [2] = {"act"},
        [3] = {"item"},
        [4] = {"spare"},
        [5] = {"defend"},
    }
    local kris_magic_buttons = { --Generally FIGHT/ACT/ITEM/SPARE/DEFEND but I used ATTACK for some reason
                           --And because it's written all over the code I can't change it anymore
                           --Not to be confused with the keys in kris_anims
        [1] = {"attack"},
        [2] = {"act"},
        [3] = {"magic"},
        [4] = {"spare"},
        [5] = {"defend"},
    }

    local krisSpecialLoops = {
        ["defend"] = "DEFEND",
        ["end"] = "endloop"
    }

    local krissheet = love.graphics.newImage("sprites/krissheet.png")
    local krisjson = love.filesystem.read("sprites/krissheet.json")
    local krissheetarr = json.decode(krisjson)

    local kris_button_states = {
        "ATTACKUI",
        "ACTUI",
        "ITEMUI",
        "SPAREUI",
        "DEFEND",
    }
    local kris_magic_button_states = {
        "ATTACKUI",
        "ACTUI",
        "MAGICUI",
        "SPAREUI",
        "DEFEND",
    }

    local kris = PartyMember("Kris", 100, 152, kris_button_states, kris_anims, "krisplace.png", "idle", krisSpecialLoops, krissheetarr, krissheet, 4, 200, 35, 10)
    kris:set_animation("attack")
    local kris_magical = PartyMember("Kris", 100, 352, kris_magic_button_states, kris_anims, "krisplace.png", "idle", krisSpecialLoops, krissheetarr, krissheet, 4, 200, 35, 10)
    kris:set_animation("attack")

    self.party_members = {
        kris,
	kris_magical,
    }

    --Load BattleUi sheet and data

    local BattleUISheet = love.graphics.newImage("sprites/battleUI.png")
    local BattleSheetQuadrant = love.filesystem.read("sprites/battleUI.json")
    local BattleSheetQuadrantData = json.decode(BattleSheetQuadrant)
    print("cwd"..love.filesystem.getWorkingDirectory())

    local KrisUI = BattleUi("Kris", "kris", "kris", kris_buttons, 288, 630, 1, BattleUISheet, BattleSheetQuadrantData)
    local Kris_mUI = BattleUi("Kris", "kris", "kris", kris_magic_buttons, 588, 630, 2, BattleUISheet, BattleSheetQuadrantData)

    self.UIs = {
        KrisUI,
	Kris_mUI
    }

    --Background
    self.Bg = Background("b")

    --Enemy related data

    --Example enemy data for a Mizzle.
    local mizzle_anims = {
        --These will remain as numbers, as the in-class code relies on numeric keys.
        [0] = {name = "mizzleIdle", length = 5, FPS = 5, looping = true, xOffset = 0, yOffset = 0},
        [1] = {name = "mizzleIdlePink", length = 5, FPS = 5, looping = true, xOffset = 0, yOffset = -0.3},
        [2] = {name = "mizzleAlarm", length = 10, FPS = 10, looping = true, xOffset = 0, yOffset = 0},
        [3] = {name = "mizzleAlarmPink", length = 10, FPS = 10, looping = true, xOffset = 0, yOffset = -0.3},
        [4] = {name = "mizzleHurt", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0},
        [5] = {name = "mizzleHurtPink", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}
    }

    self.enemies = {}

    self.enemies[1] = Mizzle("Mizzle", 980, 202, mizzle_anims, 0, 3, 1000)

    --Load your bullet sheet paths and bullet patterns here! They get passed on to the BulletManager, which handles the rest.
    self.bulletSheetPath = "sprites/mizzlebullets.png"
    self.bulletSheetDataPath = "sprites/mizzlebullets.json"

    --Each bullet pattern is a function that takes the BulletManager and dt as arguments.
    --They update BulletManager.bullets with either the new positions of the bullets or the new velocities of the bullets.
    --Custom velocities => Set BulletManager.bullets.custombulletpositions to false in your pattern function.
    --Otherwise, set it to true and add your custom movement information (you can still use BulletManager.bullets table!)
    self.bulletPatterns = {
        [1] = "mizzlebulletpattern"
    }

    --Submenus and their options
    --These get used to generate the submenus' text and their positions
    --Check out submenu.lua for more info

    self.Enemysubarray = { --The array used when generating a submenu with the enemies' names
                      --You must define the positions of the enemy names yourself.
        [1] = {"* "..self.enemies[1].name, 218, 771},
    }

    self.act_sub_subs = { --ACT -> enemies[i] (in your original array) -> These show up
        [self.enemies[1]] = { --Handle these in enemies[1]:act(actname)
            [1] = {"* Alarm", 218, 771, function () return "* Mizzr is awoken!\n* This sounds like a bad idea." end},
            [2] = {"* Lullaby", 778, 771, function (party_members) return"* "..party_members[Controller:getPartyMember()].name.." sung a lullaby!\n* Not as good as Ralsei's, but it worked." end},
        },
    }

    self.magicSubArrays = {
	[kris_magical] = {
	    [1] = {[1] = "* Instakill", [2] = 218, [3] =  771, magicFunction = function(selected_enemy) selected_enemy:hurt(1001) end, targetType = "enemy"}
	}
    }

    self.magicSubmenus = {
        Submenu(self.magicSubArrays[kris_magical], {"MAGICUI"}, nil, false)
    }

    self.Enemysub = Submenu(self.Enemysubarray, {"ATTACKUI", "ACTUI", "SPAREUI", "MAGICSUBSUB"}, nil, true)

    self.Enemysubsubs = {
        Submenu(self.act_sub_subs[self.enemies[1]], {"ACTSUBSUB"}, self.enemies[1], false),
    }

    self.PartyMemberSubArray = {
        [1] = {"* "..self.party_members[1].name, 218, 771},
	[2] = {"* kris_magical", 778, 771},
    }
    self.PartyMemberSub = Submenu(self.PartyMemberSubArray, {"MEMBERUI"}, nil, false)

    self.items = {
        [1] = Item("70cm Zurna", 180),
        [2] = Item("Ayran", 80),
        [3] = Item("S. POISON", -200),
    }

    self.ItemSubArray = {
        [1] = {"* "..self.items[1].name, 218, 771},
        [2] = {"* "..self.items[2].name, 778, 771},
        [3] = {"* "..self.items[3].name, 218, 851},
    }

    self.ItemSub = Submenu(self.ItemSubArray, {"ITEMUI"}, nil, false)

    self.ItemManager = ItemManager(self.items, self.ItemSubArray)

    love.graphics.setFont(Battlefont)

    --Music
    --This should allow one to dynamically swap songs
    --Maybe a jukebox enemy with a unique act could change the song :)
    self.MUS_Flowerbattle = love.audio.newSource("music/rakuichi_buster_wip.ogg", "stream")

    self.MUS_Battlemusic = self.MUS_Flowerbattle

    love.audio.play(self.MUS_Battlemusic)

    --Initialise program by setting the first state
    self.current_state = "BATTLEUI"
    self.UIs[1]:subtext("* Cool initial description")

    return self

end

return Encounter:new()