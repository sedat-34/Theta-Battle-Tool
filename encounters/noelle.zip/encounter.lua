--Load your custom enemies in here!

require "mizzle"

local Encounter = {}

function Encounter:new()

    self.Box = Battlebox()

    local kris_anims = {

        --These used to be number-indexed. They are now string-indexed for clarity.
        --The animations of these specific keys still need to exist for all party members.
        --(Not the names)

    ["idle"] = {name = "krisIdle", length = 6, FPS = 6, looping = true, xOffset = 0, yOffset = 0},
    ["attack"] = {name = "krisAttack", length = 8, FPS = 15, looping = false, xOffset = 5, yOffset = -20},
    ["act"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0},
	["magic"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0},
    ["item"] = {name = "krisItem", length = 8, FPS = 12, looping = false, xOffset = -21, yOffset = -15},
    ["spare"] = {name = "krisAct", length = 11, FPS = 11, looping = false, xOffset = 0, yOffset = 0}, --I'm fairly confident that Kris uses the same animation for sparing and acting.
    ["defend"] = {name = "krisDefendLoop", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -7},
    ["hurt"] = {name = "krisHurt", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -20},
    ["down"] = {name = "krisDown", length = 1, FPS = 1, looping = true, xOffset = -60, yOffset = -20},
    ["end"] = {name = "krisEnd", length = 9, FPS = 10, looping = false, xOffset = -48, yOffset = -24},
    ["endloop"] = {name = "krisEndLoop", length = 1, FPS = 1, looping = true, xOffset = -48, yOffset = -24},
    ["ATTACKUI"] = {name = "krisAttackWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = -20},
    ["ACTUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0},
	["MAGICUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}, --Testing magic with existing Kris sprites.
    ["SPAREUI"] = {name = "krisActWait", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}, --Again, sparing is visually the same as acting. 
    ["DEFEND"] = {name = "krisDefend", length = 6, FPS = 12, looping = false, xOffset = 0, yOffset = -7},
    }

    local noelle_anims = {

        --These used to be number-indexed. They are now string-indexed for clarity.
        --The animations of these specific keys still need to exist for all party members.
        --(Not the names)

	["intro"] = {name = "noelleIntro", length = 15, FPS = 15, looping = false, xOffset = -32, yOffset = -29},
    ["idle"] = {name = "noelleIdle", length = 5, FPS = 6, looping = true, xOffset = 0, yOffset = 0},
    ["attack"] = {name = "noelleAttack", length = 6, FPS = 12, looping = false, xOffset = -36, yOffset = -27},
    ["act"] = {name = "noelleAct", length = 12, FPS = 15, looping = false, xOffset = 10, yOffset = -30}, --She can't act outside N-ACT.
	["magic"] = {name = "noelleAct", length = 12, FPS = 11, looping = false, xOffset = 10, yOffset = -30}, --Temporary until I add any magic sprites for her
    ["item"] = {name = "noelleItem", length = 10, FPS = 12, looping = false, xOffset = 10, yOffset = -30},
    ["spare"] = {name = "noelleAct", length = 12, FPS = 11, looping = false, xOffset = 10, yOffset = -30}, --I'm fairly confident that everyone uses the same animation for sparing and acting.
    ["defend"] = {name = "noelleDefendLoop", length = 1, FPS = 1, looping = true, xOffset = -5, yOffset = -30},
    ["hurt"] = {name = "noelleHurt", length = 1, FPS = 1, looping = true, xOffset = -46, yOffset = -27},
    ["down"] = {name = "noelleDown", length = 1, FPS = 1, looping = true, xOffset = -46, yOffset = -27},
    ["end"] = {name = "noelleEnd", length = 8, FPS = 10, looping = false, xOffset = 0, yOffset = 0},
    ["endloop"] = {name = "noelleEndLoop", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0},
    ["ATTACKUI"] = {name = "noelleAttackWait", length = 2, FPS = 1, looping = true, xOffset = -36, yOffset = -27},
    ["ACTUI"] = {name = "noelleActWait", length = 2, FPS = 5, looping = true, xOffset = 10, yOffset = -30},
	["MAGICUI"] = {name = "noelleActWait", length = 2, FPS = 5, looping = true, xOffset = 10, yOffset = -30}, --Honestly don't know
	["ITEMUI"] = {name = "noelleItemWait", length = 2, FPS = 2, looping = true, xOffset = 0, yOffset = 0},
    ["SPAREUI"] = {name = "noelleActWait", length = 2, FPS = 5, looping = true, xOffset = 0, yOffset = 0}, --Again, sparing is visually the same as acting. 
    ["DEFEND"] = {name = "noelleDefend", length = 6, FPS = 12, looping = false, xOffset = -5, yOffset = -30},
   }

    local kris_buttons = { --Generally FIGHT/ACT/ITEM/SPARE/DEFEND but I used ATTACK for some reason
                           --And because it's written all over the code I can't change it anymore
                           --Not to be confused with the keys in kris_anims
        [1] = {"attack"},
        [2] = {"act"},
        [3] = {"item"},
        [4] = {"spare"},
        [5] = {"defend"},
    }
    local noelle_buttons = { 

        [1] = {"attack"},
        [2] = {"magic"},
        [3] = {"item"},
        [4] = {"spare"},
        [5] = {"defend"},
    }

    local memberSpecialLoops = {
        ["DEFEND"] = "defend",
        ["end"] = "endloop"
    }

    local krissheet = love.graphics.newImage("sprites/krissheet.png")
    local krisjson = love.filesystem.read("sprites/krissheet.json")
    local krissheetarr = json.decode(krisjson)

    local noellesheet = love.graphics.newImage("sprites/noellesheet.png")
    local noellejson = love.filesystem.read("sprites/noellesheet.json")
    local noellesheetarr = json.decode(noellejson)

    local kris_button_states = {
        "ATTACKUI",
        "ACTUI",
        "ITEMUI",
        "SPAREUI",
        "DEFEND",
    }
    local noelle_button_states = {
        "ATTACKUI",
        "MAGICUI",
        "ITEMUI",
        "SPAREUI",
        "DEFEND",
    }

    local kris = PartyMember("Kris", 100, 152, kris_button_states, kris_anims, "krisplace.png", "idle", memberSpecialLoops, krissheetarr, krissheet, 4, 200, 35, 10)
    kris:set_animation("attack")
    local noelle = PartyMember("Noelle", 100, 352, noelle_button_states, noelle_anims, "noellePlace.png", "idle", memberSpecialLoops, noellesheetarr, noellesheet, 4, 200, 35, 10)
    noelle:set_animation("intro")

    self.party_members = {
	kris,
	noelle,
    }

    --Load BattleUi sheet and data

    local BattleUISheet = love.graphics.newImage("sprites/battleUI.png")
    local BattleSheetQuadrant = love.filesystem.read("sprites/battleUI.json")
    local BattleSheetQuadrantData = json.decode(BattleSheetQuadrant)

    local KrisUI = BattleUi("Kris", "kris", "kris", kris_buttons, 268, 630, 1, BattleUISheet, BattleSheetQuadrantData)
    local NoelleUI = BattleUi("Noelle", "noelle", "noelle", noelle_buttons, 608, 630, 2, BattleUISheet, BattleSheetQuadrantData) --Temporarily using Kris' header and bg until I implement Noelle's.

    self.UIs = {
        KrisUI,
	NoelleUI
    }

    --Background
    self.Bg = Background("b")

    --Enemy related data

    --Example enemy data for a Mizzle.
    local mizzle_anims = {
        --These will remain as numbers, as the in-class code relies on numeric keys.
        [0] = {name = "mizzleIdle", length = 5, FPS = 5, looping = true, xOffset = 0, yOffset = 0},
        [1] = {name = "mizzleIdlePink", length = 5, FPS = 5, looping = true, xOffset = 0, yOffset = -0.3},
        [2] = {name = "mizzleAlarm", length = 10, FPS = 10, looping = true, xOffset = 0, yOffset = 0},
        [3] = {name = "mizzleAlarmPink", length = 10, FPS = 10, looping = true, xOffset = 0, yOffset = -0.3},
        [4] = {name = "mizzleHurt", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0},
        [5] = {name = "mizzleHurtPink", length = 1, FPS = 1, looping = true, xOffset = 0, yOffset = 0}
    }

    self.enemies = {
	[1] = Mizzle("Mizzle", 980, 202, mizzle_anims, 0, 3, 1000)
    }

    --Load your bullet sheet paths and bullet patterns here! They get passed on to the BulletManager, which handles the rest.
    self.bulletSheetPath = "sprites/mizzlebullets.png"
    self.bulletSheetDataPath = "sprites/mizzlebullets.json"

    --Each bullet pattern is a function that takes the BulletManager and dt as arguments.
    --They update BulletManager.bullets with either the new positions of the bullets or the new velocities of the bullets.
    --Custom velocities => Set BulletManager.bullets.custombulletpositions to false in your pattern function.
    --Otherwise, set it to true and add your custom movement information (you can still use BulletManager.bullets table!)
    --Right now each pattern executes for a set 5 seconds.
    self.bulletPatterns = {
        [1] = "mizzlebulletpattern"
    }

    --Submenus and their options
    --These get used to generate the submenus' text and their positions
    --Check out submenu.lua for more info

    self.Enemysubarray = { --The array used when generating the submenu with the enemies' names
        [1] = {name = self.enemies[1].name},
    }

    self.act_sub_subs = { --ACT -> enemies[i] (in your original array) -> These show up
        [self.enemies[1]] = { --Handle these in enemies[1]:act(actname)
            [1] = {name = "Alarm", subtext = function () return "* Mizzr is awoken!\n* This sounds like a bad idea." end},
            [2] = {name = "Lullaby", subtext = function (party_member) return "* "..party_member.name.." sung a lullaby!\n* Not as good as Ralsei's, but it worked." end},
        },
    }

    self.magicSubArrays = {
	[noelle] = {
	    [1] = {name = "Instakill", magicFunction = function(selected_enemy) selected_enemy:hurt(1001) end, subtext = "Noelle cast instakill!", targetType = "enemy"},
	    [2] = {name = "N-ACT", magicFunction = function(selected_enemy) noelle:act(selected_enemy, "N-ACT") end, subtext = function(selected_enemy) return selected_enemy:subtext("N-ACT") end}
	}
    }

    self.magicSubmenus = {
        Submenu(self.magicSubArrays[noelle], {"MAGICUI"}, "partymember", self.party_members[2])
    }

    self.Enemysub = Submenu(self.Enemysubarray, {"ATTACKUI", "ACTUI", "SPAREUI", "MAGICSUBSUB"}, "enemylist", nil)

    self.Enemysubsubs = {
        Submenu(self.act_sub_subs[self.enemies[1]], {"ACTSUBSUB"}, "enemy", self.enemies[1]),
    }

    self.PartyMemberSubArray = {
        [1] = {name = self.party_members[1].name},
	[2] = {name = self.party_members[2].name},
    }

    self.PartyMemberSub = Submenu(self.PartyMemberSubArray, {"MEMBERUI"}, "other", nil)

    self.items = {
        [1] = Item("70cm Zurna", 180),
        [2] = Item("Ayran", 80),
        [3] = Item("S. POISON", -200),
    }

    self.ItemSubArray = {
        [1] = {name = self.items[1].name},
        [2] = {name = self.items[2].name},
        [3] = {name = self.items[3].name},
    }

    love.graphics.setFont(Battlefont)

    --Music
    --This should allow one to dynamically swap songs
    --Maybe a jukebox enemy with a unique act could change the song :)
    self.MUS_Flowerbattle = love.audio.newSource("music/rakuichi_buster_wip.ogg", "stream")

    self.MUS_Battlemusic = self.MUS_Flowerbattle

    love.audio.play(self.MUS_Battlemusic)

    --Initialise program by setting the first state
    self.current_state = "BATTLEUI"
    self.UIs[1]:subtext("* Cool initial description")

    return self

end

return Encounter:new()